using System.Reflection;

[assembly: AssemblyCompany("Illusory Studios LLC")]
[assembly: AssemblyCopyright("Copyright 2010-2014 James F. Bellinger <http://www.zer7.com/software/cryptsharp>")]
[assembly: AssemblyProduct("CryptSharp")]
[assembly: AssemblyTitle("CryptSharp.Demo")]
